import styles from "./ForgotPassword.module.scss";
import { NavLink } from "react-router-dom";
import { IoIosMail } from "react-icons/io";
import { FaFacebook, FaTwitter, FaGoogle } from "react-icons/fa";

const Login = () => {
  return (
    <div className={styles.forgotPassword}>
      <form className={styles.forgotPasswordForm}>
        <h2>Forgot password</h2>
        <label htmlFor="username">Email:</label>
        <div className={styles.inputWithIcon}>
          <IoIosMail className={styles.icon} />
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email"
          />
        </div>

        <input type="submit" value="Reset my Password" />

        <NavLink className={styles.navItem} to="/register">
          Create account
        </NavLink>

        <p>Or Sign up using:</p>
        <div className={styles.socialIcons}>
          <NavLink to="http://facebook.com">
            <FaFacebook className={styles.socialIconFb} />
          </NavLink>
          <NavLink to="http://x.com">
            <FaTwitter className={styles.socialIconTw} />
          </NavLink>
          <NavLink to="http://gmail.com">
            <FaGoogle className={styles.socialIconG} />
          </NavLink>
        </div>
      </form>
    </div>
  );
};

export default Login;
